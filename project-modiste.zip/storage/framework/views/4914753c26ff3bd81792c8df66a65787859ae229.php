<?php $__env->startSection('tabel'); ?>
<div class="product-status mg-b-30">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
        <div class="product-status-wrap">
          <h4>Tanggal Pembelian</h4>
          <p style="color: white;"><?= date('d F Y') ?></p>
        </div>
      </div>
      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
        <div class="product-status-wrap">
          <h4>Supplier</h4>
          <p style="color: white;"><?php echo e($supplier->nama_agen); ?></p>
        </div>
      </div>
    </div>
  </div>
</div>
<form action="<?php echo e(route('pembelian.store')); ?>" method="POST" enctype="multipart/form-data">
  <?php echo csrf_field(); ?>
  <input name="supplier" type="hidden" class="form-control" value="<?php echo e($supplier->id); ?>" hidden>
  <input name="tanggal" type="hidden" class="form-control" value="<?= date('Y-m-d') ?>" hidden>

  <div class="data-transaksi">
    <div class="product-status mg-b-30">
      <div class="container-fluid">
        <div class="row">
          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="product-status-wrap">
              <h4>Barang</h4>

              <div class="product-tab-list tab-pane fade active in" id="description">
                <div class="row">
                  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="review-content-section">
                      <div class="input-group mg-b-pro-edt">
                        <span class="input-group-addon"><i class="fa fa-archive" aria-hidden="true"></i></span>
                        <select name="namaBarang[]" type="text" class="form-control" placeholder="Nama Barang" required>
                          <option value="" hidden>Nama Barang</option>
                          <?php $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($barang->id); ?>"><?php echo e($barang->nama_barang); ?> | <?php echo e($barang->harga_agen); ?>  | <?php echo e($barang->ukuran); ?> | <?php echo e($barang->warna); ?> </option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div>
                      <div class="input-group mg-b-pro-edt">
                        <span class="input-group-addon"><i class="fa fa-usd" aria-hidden="true"></i></span>
                        <input name="jumlahBarang[]" type="number" class="form-control" placeholder="Jumlah" required>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="product-status mg-b-30">
    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
          <div class="product-status-wrap">

            <button type="submit" class="btn btn-primary" style="color:white">Masukan Transaksi
            </button>
            <div class="btn btn-success add-data" style="color:white">Tambah Data
            </div>
            
          </div>
        </div>
        <!-- <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
          <div class="product-status-wrap">
            <div>
                <p style="color: orange;">Jumlah total yang dibayar yaitu RP </p>
            </div>
          </div>
        </div> -->
      </div>
    </div>
  </div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('addData'); ?>
<script>
  $(".add-data").click(function() {
    let div = `
    <div class="product-status mg-b-30">
    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <div class="product-status-wrap">
            <h4>Barang</h4>

            <div class="product-tab-list tab-pane fade active in" id="description">
              <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                  <div class="review-content-section">
                    <div class="input-group mg-b-pro-edt">
                      <span class="input-group-addon"><i class="fa fa-archive" aria-hidden="true"></i></span>
                      <select name="namaBarang[]" type="text" class="form-control" placeholder="Nama Barang" required>
                        <option value="" hidden>Nama Barang</option>
                        <?php $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($barang->id); ?>"><?php echo e($barang->nama_barang); ?> | <?php echo e($barang->harga_agen); ?>  | <?php echo e($barang->ukuran); ?> | <?php echo e($barang->warna); ?> </option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                    <div class="input-group mg-b-pro-edt">
                      <span class="input-group-addon"><i class="fa fa-usd" aria-hidden="true"></i></span>
                      <input name="jumlahBarang[]" type="number" class="form-control" placeholder="Jumlah" required>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>`;

    $('.data-transaksi').append(div);
  });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout-admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\backup aplikasi\project-modiste\resources\views/pembelian/index.blade.php ENDPATH**/ ?>