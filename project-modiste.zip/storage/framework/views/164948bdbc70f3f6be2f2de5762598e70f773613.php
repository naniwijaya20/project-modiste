<?php $__env->startSection('tabel'); ?>
<?php if(session('message')): ?>
<div style="margin:10px 20px" class="alert alert-success" role="alert">
  <?php echo e(session('message')); ?>

</div>
<?php endif; ?>
<div class="product-status mg-b-30">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
        <div class="product-status-wrap">
          <h4>Tanggal Pembelian</h4>
          <p style="color: white;"><?= date('d F Y') ?></p>
        </div>
      </div>
      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
        <div class="product-status-wrap">
          <h4>Supplier</h4>
          <p style="color: white;"><?php echo e($sup); ?></p>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="data-transaksi">
  <div class="product-status mg-b-30">
    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <div class="product-status-wrap">
            <h4>Tabel Transaksi No. <?php echo e($noTrans); ?></h4>
            <table>
              <tr>
                <th>No</th>
                <th>Nama Barang</th>
                <th>Harga</th>
                <th>Ukuran Barang</th>
                <th>Warna Barang</th>
                <th>Jumlah Barang</th>
                <th>Total</th>
              </tr>
              <?php $no = 1 ;
                $total = 0;
                $totalSemua = 0;
              ?>
              <?php $__currentLoopData = $detailPembelians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($no++); ?></td>
                <td><?php echo e($item->barangs->nama_barang); ?></td>
                <td><?php echo e($item->barangs->harga_agen); ?></td>
                <td><?php echo e($item->barangs->ukuran); ?></td>
                <td><?php echo e($item->barangs->warna); ?></td>
                <td><?php echo e($item->jumlah); ?></td>
                <td><?php echo e($total = $item->barangs->harga_agen * $item->jumlah); ?></td>
                <?php $totalSemua = $totalSemua + $total ?>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <th colspan="6">Total Semua</th>
                <th>Rp. <?php echo e($totalSemua); ?></th>
              </tr>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout-admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\backup aplikasi\project-modiste\resources\views/pembelian/detail-transaksi.blade.php ENDPATH**/ ?>