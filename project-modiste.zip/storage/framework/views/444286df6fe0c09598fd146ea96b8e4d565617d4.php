<?php $__env->startSection('tabel'); ?>
<div class="product-status mg-b-30">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="product-status-wrap">
                    <h4>Tabel Pembelian</h4>
                    <div class="add-product">
                        <a href="barang/create">Barang Baru</a>
                    </div>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="col-md-9 col-md-9 col-sm-9 col-xs-12">
                        <div class="row">
                            <div class="col-md-3">
                                <div class="hpanel mt-b-30">
                                    <div class="panel-body file-body file-cs-ctn">
                                        <i class="fa fa-file-png-o text-info"></i>
                                    </div>
                                    <div class="panel-footer">
                                        <a href="#">gambar</a>
                                    </div>
                                    </div>
                                    </div>
                                    </div>
                    <table>
                        <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                    <div class="custom-pagination">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout-admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SKRIPSI\git-modiste\project-modiste\resources\views/pembelian/index.blade.php ENDPATH**/ ?>